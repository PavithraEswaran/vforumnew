//package com.vforum.test;
//
//
//import org.springframework.context.annotation.ComponentScan;
//
//@ComponentScan(basePackages = "com.vforum")
//public class TestBeanConfig {
//
//}