//package com.vforum.test;
//
//
//import org.junit.Assert;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//import org.springframework.test.annotation.Rollback;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.vforum.dao.EmployeeDao;
//import com.vforum.model.Employee;
//
//
//@ContextConfiguration(locations = "classpath:application-context-test.xml")
//@RunWith(SpringJUnit4ClassRunner.class)
//
//public class EmployeeDaoTest {
//    @Autowired
//    private EmployeeDao employeeDAO;
//     
//   
//     
//    @Test
//    @Transactional
//    @Rollback(true)
//    public void getEmployee()
//    {
//    	Employee emp=new Employee(8063704,"pavithra","associateengineer","chennai","pavithra","Pavi@123");
//    	Employee emptest=employeeDAO.getEmployee(8063704);
//    	
//    	 Assert.assertEquals(emp.getEmployeeName(),emptest.getEmployeeName());
//    	 Assert.assertEquals(emp.getEmployeeLocation(),emptest.getEmployeeLocation());
//    	 Assert.assertEquals(emp.getEmployeeDesignation(),emptest.getEmployeeDesignation());
//
//    	 Assert.assertEquals(emp.getUsername(),emptest.getUsername());
//    	 Assert.assertEquals(emp.getPassword(),emptest.getPassword());
//    }
//
//
//}
